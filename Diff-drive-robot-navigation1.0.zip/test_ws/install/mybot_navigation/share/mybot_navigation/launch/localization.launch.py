import os

from launch import LaunchDescription

from launch_ros.actions import Node

from ament_index_python.packages import get_package_share_directory



def generate_launch_description():


    # 获取功能包路径
    pkg_path = get_package_share_directory("mybot_navigation")

 
    # 地图路径
    map_file = os.path.join(pkg_path,"maps","my_map.yaml")


    # AMCL参数路径
    amcl_config = os.path.join(pkg_path,"config","amcl.yaml")


    # 地图服务器
    map_server = Node(
        package="nav2_map_server",
        executable="map_server",
        name="map_server",
        output="screen",
        parameters=[
            {
                "yaml_filename": map_file,
                "use_sim_time": True
            }
        ]
    )


    # AMCL定位节点
    amcl = Node(
        package="nav2_amcl",
        executable="amcl",
        name="amcl",
        output="screen",
        parameters=[amcl_config]
    )



    return LaunchDescription(
        [
            map_server,
            amcl,
            Node(
    package="nav2_lifecycle_manager",
    executable="lifecycle_manager",
    name="lifecycle_manager_localization",
    parameters=[
        {
            "autostart": True,
            "node_names":[
                "map_server",
                "amcl"
            ]
        }
    ]
)

        ]
    )