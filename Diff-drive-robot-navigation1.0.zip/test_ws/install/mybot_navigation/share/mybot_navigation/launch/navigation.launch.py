import os

from launch import LaunchDescription
from launch_ros.actions import Node

from ament_index_python.packages import get_package_share_directory



def generate_launch_description():


    pkg = get_package_share_directory(
        "mybot_navigation"
    )


    config_path = os.path.join(
        pkg,
        "config"
    )


    planner_yaml = os.path.join(
        config_path,
        "planner.yaml"
    )


    controller_yaml = os.path.join(
        config_path,
        "controller.yaml"
    )


    behavior_yaml = os.path.join(
        config_path,
        "behavior.yaml"
    )


    bt_yaml = os.path.join(
        config_path,
        "bt_navigator.yaml"
    )


    global_costmap_yaml = os.path.join(
        config_path,
        "global_costmap.yaml"
    )


    local_costmap_yaml = os.path.join(
        config_path,
        "local_costmap.yaml"
    )


    global_costmap_yaml = os.path.join(
    config_path,
    "global_costmap.yaml"
    )


    local_costmap_yaml = os.path.join(
    config_path,
    "local_costmap.yaml"
    )





    
    # 全局路径规划

    planner = Node(
        package="nav2_planner",
        executable="planner_server",
        name="planner_server",
        # output="screen",
        parameters=[
            planner_yaml,
            global_costmap_yaml
        ]
    )



    # 局部控制

    controller = Node(
        package="nav2_controller",
        executable="controller_server",
        name="controller_server",
        # output="screen",
        parameters=[
            controller_yaml,
            local_costmap_yaml
        ]
    )



    # 行为树导航

    bt = Node(
        package="nav2_bt_navigator",
        executable="bt_navigator",
        name="bt_navigator",
        output="screen",
        parameters=[
            bt_yaml
        ]
    )



    # 恢复行为

    behavior = Node(
        package="nav2_behaviors",
        executable="behavior_server",
        name="behavior_server",
        # output="screen",
        parameters=[
            behavior_yaml
        ]
    )



    # 生命周期管理

    lifecycle = Node(
        package="nav2_lifecycle_manager",
        executable="lifecycle_manager",
        name="lifecycle_manager_navigation",
        # output="screen",
        parameters=[
            {
                "use_sim_time": True,

                "autostart": True,

                "node_names":[

                    "planner_server",

                    "controller_server",

                    "bt_navigator",

                    "behavior_server"

                ]
            }
        ]
    )



    return LaunchDescription([

        planner,

        controller,

        bt,

        behavior,

        lifecycle

    ])