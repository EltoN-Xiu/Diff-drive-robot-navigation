import os

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription

from launch.launch_description_sources import PythonLaunchDescriptionSource

from ament_index_python.packages import get_package_share_directory



def generate_launch_description():


    pkg_path=get_package_share_directory('mybot_slam')
    slam_config_path=os.path.join(pkg_path,'config','slam_params.yaml')


    # 引入slam_toolbox官方launch
    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('slam_toolbox'),
                'launch',
                'online_async_launch.py'
            )
        ),
        launch_arguments={
                    'slam_params_file': slam_config_path,
                    'use_sim_time': 'True',
                    }.items()
    )


    return LaunchDescription(
        [
            slam_launch
        ]
    )