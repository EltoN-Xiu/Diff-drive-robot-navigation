import launch
import launch_ros
from ament_index_python.packages import get_package_share_directory
from launch.substitutions import Command
import xacro
from launch_ros.actions import Node


def generate_launch_description():
    # 获取默认路径
    pkg_path = get_package_share_directory('my_robot')
    model_path = pkg_path + '/urdf/my_robot.urdf'
    diff_driver_path=pkg_path+'/urdf/diff_driver/diff_driver.urdf.xacro'


    # with open(model_path, 'r') as f:
    #      robot_description = f.read()

    robot_description = xacro.process_file(diff_driver_path).toxml()


    robot_state_publisher_node = launch_ros.actions.Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description':robot_description}]
    )
    # # 关节状态发布节点
    # joint_state_publisher_node = launch_ros.actions.Node(
    #     package='joint_state_publisher',
    #     executable='joint_state_publisher',
    # )
    # RViz 节点
    rviz_node = launch_ros.actions.Node(
        package='rviz2',
        executable='rviz2',
        # arguments=['-d', rviz_config]
    )
    return launch.LaunchDescription([
        # joint_state_publisher_node,
        robot_state_publisher_node,
        rviz_node,

        Node(
            package='joint_state_publisher',
            executable='joint_state_publisher'
        ),


       
    ])
