from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess,IncludeLaunchDescription
import os
import xacro
import launch
import launch_ros
from ament_index_python.packages import get_package_share_directory
from launch.actions import TimerAction


def generate_launch_description():
    pkg_path=get_package_share_directory('my_robot')
    
    # xacro_file=pkg_path+'/urdf/diff_driver/diff_driver.urdf.xacro'
    bridge_config_path=os.path.join(pkg_path,'config','gazebo_bridge.yaml')
    # slam_config_path=os.path.join(pkg_path,'config','slam_params.yaml')



    xacro_file=os.path.join(pkg_path,'urdf','diff_driver','diff_driver.urdf.xacro')
    # xacro_file= os.path.join(pkg_path, 'urdf', 'fishbot', 'fishbot.urdf.xacro')
    world_path=os.path.join(pkg_path,'worlds','my_world.sdf')
    rviz_path = os.path.join(pkg_path, 'config', 'display_robot_model.rviz')


    # robot_description_file = xacro.process_file(xacro_file).toxml()


    robot_description_content = launch.substitutions.Command(
        ['xacro ', xacro_file]
    )
    robot_description = launch_ros.parameter_descriptions.ParameterValue(
        robot_description_content, value_type=str
    )

    # # 获取xacro文件内容
    # robot_description_content = launch.substitutions.Command(
    #     ['xacro ', xacro_file]
    # )
    # robot_description= launch_ros.parameter_descriptions.ParameterValue(
    #     robot_description_content, value_type=str
    # )


    

    return LaunchDescription([
        

        # ExecuteProcess(
        #     cmd=['gz','sim','./src/my_robot/worlds/my_world.sdf'],
        #     # ./src/my_robot/worlds/my_world.sdf
        #     output='screen'
        # ),

        IncludeLaunchDescription(
        launch.launch_description_sources.PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': [world_path,' -s'' -r']}.items()
        ),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description':robot_description,
                        #  "frame_prefix": "diff_driver/",
                         'use_sim_time': True}],
            output='screen'
        ),

        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            parameters=[{'config_file':bridge_config_path}],
            output='screen'
        ),


        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-topic','robot_description',
                       '-z','0.1'
                       ]
        ),

       
         


        # Node(
        #     package='joint_state_publisher',
        #     executable='joint_state_publisher',
        # ),
        
        # IncludeLaunchDescription(
        #     launch.launch_description_sources.PythonLaunchDescriptionSource(
        #             os.path.join(
        #                 get_package_share_directory('slam_toolbox'),
        #                 'launch',
        #                 'online_async_launch.py'
        #             )
                    
        #         ),
        #             launch_arguments={
        #             'slam_params_file': slam_config_path,
        #             'use_sim_time': 'True',
        #             }.items()
        #     ),






#        TimerAction(
#     period=2.0,
#     actions=[
#         Node(
#             package='rviz2',
#             executable='rviz2',
#             parameters=[{'use_sim_time':True}]
#         )
#     ]
# )

    ])
